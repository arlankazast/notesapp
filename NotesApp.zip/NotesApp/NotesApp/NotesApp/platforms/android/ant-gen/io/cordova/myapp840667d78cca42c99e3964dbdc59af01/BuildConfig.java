/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp840667d78cca42c99e3964dbdc59af01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";
    var FNAME = 'mydataFile.db',
       file = {
           writer: { available: false },
           reader: { available: false }
       },
       dataEntries = [];


    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener('resume', onResume.bind(this), false);
        document.getElementById("btnSave").addEventListener('click', saveText.bind(this), false);
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS);
       
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };
    function gotFS(fs) {
        fs.root.getFile(FNAME, { create: true, exclusive: false },
                        gotFileEntry);
    }

    function gotFileEntry(fileEntry) {
        file.entry = fileEntry;
        fileEntry.createWriter(gotFileWriter);
        readText();
    }

    function gotFileWriter(fileWriter) {
        file.writer.available = true;
        file.writer.object = fileWriter;
    }
    function saveText(e) {
        var txt = document.getElementById('desc').value;
        dataEntries.push('\n' + txt);
        document.getElementById('desc').value = '';
        document.getElementById('txtContainer').innerHTML = dataEntries.join('');
        if (file.writer.available) {
            file.writer.available = false;
            file.writer.object.onwriteend = function (evt) {
                file.writer.available = true;
                file.writer.object.seek(0);
            }
            file.writer.object.write(dataEntries.join("\n"));
        }
        return false;
    }
    function readText() {
        if (file.entry) {
            file.entry.file(function (dbFile) {
                var reader = new FileReader();
                reader.onloadend = function (evt) {
                    var textArray = evt.target.result.split("\n");
                    dataEntries = textArray.concat(dataEntries);
                    document.getElementById('txtContainer').innerHTML = dataEntries.join(' ');
                }
                reader.readAsText(dbFile);
            });
        }
        return false;
    }

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
} )();